import * as actionCreators from "./action-creators/index"
export default actionCreators