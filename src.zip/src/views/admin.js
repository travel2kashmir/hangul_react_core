import React from 'react'

function admin() {
  return (
    <div>admin</div>
  )
}

export default admin